# My Personal AGI — Starter Bundle v0.2

One download, everything connected. Day one is already done for you.

## Start here (five minutes)

1. Put this whole folder somewhere simple and permanent — your documents folder, your vault.
2. Open **`index.html`** in your browser. That's Mission Control.
3. Do the **two-minute start** on that page: name what you're carrying (1–3 things is plenty — a student can stop there), and it drafts your starter **SOUL.md** and fills your tabs.
4. Save the downloaded `SOUL.md` into this folder, next to `index.html`, and point your AI at it.
5. Bookmark `index.html` under **Dashboards**.

That's a complete beginning. Everything else is optional depth, added later, at your pace.

## What's in this folder

```text
My-Personal-AGI/
  index.html          ← Mission Control: your tabs, module rail, and two-minute start
  SOUL.md             ← you add this (step 4 above); the full SOUL Quiz can replace it later
  Memory/             ← yours to fill — working records live here
    TRUST-LEDGER.md            every handoff run, promotion, and revocation
    MONTHLY-MEMORY-REVIEW.md   your monthly review + PHI self-audit log
    spheres/                   what your AI may remember about you, by sphere
  19-Memory-Fabric/   ← the reference library: rules, handoff cards, templates (read, don't fill)
```

## Going deeper, when you're ready

- The full [SOUL Quiz](https://nurse-ai-os.org/soul-quiz.html) writes a richer SOUL.md — replace the starter one.
- The full [Life & Projects Quiz](https://nurse-ai-os.org/life-quiz.html) maps all 17 life domains — import its `naio-projects.json` in Mission Control and it replaces the starter map.
- Run your first handoff card from `19-Memory-Fabric/handoff-cards/` and log it in `Memory/TRUST-LEDGER.md`.
- Mission Control will gently remind you after a month; minimal remains a valid choice.

## The rules this bundle lives under

No PHI, ever. Local-first — these are your files on your device; nothing here uploads anything. Draft-and-attest — your AI prepares, you commit. Ceilings: Green/Yellow, D0/D1, Observe → Draft → Recommend. Downloading and opening this bundle installs nothing and activates nothing.

*Agents propose. Humans judge. Nurses steward.*
