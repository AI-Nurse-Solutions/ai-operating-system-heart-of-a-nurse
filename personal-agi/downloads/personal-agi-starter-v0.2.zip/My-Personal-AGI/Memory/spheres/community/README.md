# Community sphere

Notes your AI may keep about your community sphere live here — one topic per file, plainly named. No PHI, no employer secrets, no credentials, ever. See `../../19-Memory-Fabric/VAULT-STRUCTURE.md` for the rules.
