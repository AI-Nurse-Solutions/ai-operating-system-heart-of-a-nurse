# The NIN/NAIO Nurse Entrepreneur Program

**Formal launch: September 15–17** · Founding enrollment opens at launch. Kit builders get first invitation.

---

## What it is

The Nurse Entrepreneur Program is the venture-building arm of the NIN ecosystem — a guided, phase-based journey that turns nurses and healthcare professionals into **AI-native founders**. It does not teach a specific tool. It teaches you to **design, govern, and scale AI-enabled organizations** that create value for people and the planet.

> Develop the steward → Learn AI orchestration → Build your own AI OS → Launch an AI-enabled venture → Scale into a sovereign organization that creates value for people and the planet.

Three convictions set it apart:

1. **Model-agnostic by design.** You learn AI thinking and orchestration, so the program stays relevant no matter which models dominate.
2. **Impact-first by conviction.** Not every company should maximize profit — some maximize impact. Impact enterprises are first-class here.
3. **Governed from day one.** EDENA governance is embedded in every phase as a competitive advantage, not a compliance burden.

**This starter kit is Phase 0 in miniature.** Finish your 30-day sprint and you have already practiced the program's first moves: one safe artifact, real nurse conversations, and a go/no-go decision made with human judgment.

---

## The journey — 11 phases, each with a real deliverable

### Foundations (Phases 0–2)
- **Phase 0 — Identity: Discover Your Why.** Before building AI, build the founder. Answer: What world do I want to improve? What am I uniquely qualified to solve? What gives me credibility? What values are non-negotiable? What boundaries protect people? → *Output: a Steward Entrepreneur* (mission, personal constitution, values, EDENA profile).
- **Phase 1 — Opportunity Discovery.** Ask "what human problem deserves solving?", not "what business should I start?" Pain interviews, market maps, evidence folders. → *Output: a Validated Opportunity.*
- **Phase 2 — AI-Native Founder.** Learn AI first — thinking, not coding. Prompting, research, reasoning, memory, knowledge management. → *Output: an AI-Native Founder* with a personal workspace and founder AI assistant.

### Founder OS (Phases 3–5)
- **Phase 3 — Personal AI Chief of Staff.** The unique core of the program: build *your own* chief of staff with Hermes — daily dashboard, knowledge vault, decision and reflection systems, calendar and task orchestration. → *Output: your Founder OS.*
- **Phase 4 — AI Workforce.** Begin hiring AI — agents, not people yet. Research, marketing, operations, finance, support, content departments, each with its own governance. → *Output: an AI Company of One.*
- **Phase 5 — Workflow Engineering.** Every business decomposes into inputs → decisions → actions → outputs → learning, with human decision gates and KPIs. → *Output: a Workflow Engine.*

### Venture (Phases 6–7)
- **Phase 6 — Build Your MVP.** From "I have an idea" to building: course, kit, consultancy, community, SaaS, marketplace, or media. Prototype, landing page, pilot, beta. → *Output: a Working Product.*
- **Phase 7 — First Revenue.** Pricing, offers, sales, customer discovery, testimonials, iteration. → *Output: Revenue.*

### Scale & Stewardship (Phases 8–10)
- **Phase 8 — Scale.** When demand exceeds capacity: AI departments and an executive agent staff. → *Output: an AI Enterprise.*
- **Phase 9 — Sovereignty.** Choose your deployment — cloud, hybrid, local, self-hosted, institutional — and own your stack and your data. → *Output: a Sovereign AI Organization.*
- **Phase 10 — Scale Good.** Tracks for healthcare, education, climate, community, government, faith, non-profit, and humanitarian work. → *Output: an Impact Enterprise.*

---

## The Growth Ladder

Each phase completed (and its EDENA gate passed) advances you one level:

| Level | Title | Goal |
|------|-------|------|
| 0 | Steward | Identity, values, mission |
| 1 | Explorer | Discover opportunities |
| 2 | AI Native | Learn AI thinking |
| 3 | Orchestrator | Build a personal AI OS |
| 4 | Builder | Create products and workflows |
| 5 | Entrepreneur | Acquire customers and revenue |
| 6 | Operator | Manage AI departments |
| 7 | Founder | Lead an AI-first company |
| 8 | Architect | Design sovereign AI systems |
| 9 | Steward Leader | Scale organizations that benefit society |

---

## How it fits the ecosystem

- **HERMES** — executes governed actions and automations; persistent memory and knowledge.
- **Florence-X** — coordinates agents, workflows, and decisions (orchestration).
- **EDENA** — the governance layer active in every phase.
- **NIN** (Nurse Intelligence Network) — nursing and healthcare depth.
- **Nurse Entrepreneur** — the venture-building arm (this program).
- **FMN** (Florence Media Network) — education, community, and audience growth.

## The EDENA gate — asked at every phase

Is it ethical? Is it defensible? Is it explainable? Does it respect privacy? Does it preserve human accountability? Does it create long-term value? **No phase is complete until the answer is yes.**

---

## How to get invited

Formal launch is **September 15–17**. Email **great.ai.nurses@gmail.com** with the subject "Nurse Entrepreneur Program — Founding Interest" and tell us (no PHI): your role, region, where you are on the journey, and what you would build if it worked. A human reads every note. No automatic enrollment; no payment collected before launch.

*Carry the lamp. Keep the ledger. Agents propose. Humans judge. Nurses steward.*
